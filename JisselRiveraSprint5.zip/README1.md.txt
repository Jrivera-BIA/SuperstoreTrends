Dashboard Link: https://public.tableau.com/views/JisselRivera5/TotalSalesVs_Returns?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

Google Slide Link: https://docs.google.com/presentation/d/1SQBDRlG8f8l0x4dYq_9aglbC1jWUepr2YP-C2cXeM6o/edit?usp=sharing